package com.jdca.proyectofinal.Model

import java.io.Serializable

data class Laboratorio(
    val codLaboratorio: String,
    val pabellon: String,
    val piso: String
) : Serializable